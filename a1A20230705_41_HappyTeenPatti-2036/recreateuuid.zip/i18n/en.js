"use strict";
module.exports = {
    description: "Recreate UUID and link it",
    developer: "Developer",
    label: "Recreate UUID",
    selecttitle: "Please select the root where you need refresh uuid",
    yourSelect: "Selected Root",
    warningMsg: "Do you want to recreate the UUIDs of all files in the selected directory?\nplease backup the resources!!!",
    warningTitle: "Warning",
    warningBtnSure: "OK",
    warningBtnCancel: "Cancel"
};